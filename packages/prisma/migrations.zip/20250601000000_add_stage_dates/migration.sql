-- AlterTable
ALTER TABLE "project_stages" ADD COLUMN "startDate" TIMESTAMP(3);
ALTER TABLE "project_stages" ADD COLUMN "receivedDate" TIMESTAMP(3);
ALTER TABLE "project_stages" ADD COLUMN "completedDate" TIMESTAMP(3);
