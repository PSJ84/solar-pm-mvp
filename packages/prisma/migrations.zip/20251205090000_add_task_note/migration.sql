-- AlterTable
ALTER TABLE "tasks" ADD COLUMN "note" TEXT;
